window.onscroll = function(){

    
    if(document.documentElement.scrollTop>100){
         document.getElementById("nav").classList.add("nextnav");
    
    }else{
    
        document.getElementById("nav").classList.remove("nextnav");
    }
    
    }